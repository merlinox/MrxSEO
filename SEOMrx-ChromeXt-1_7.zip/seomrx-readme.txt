1.7 20210804	Img without width|height
1.6 20210127    Nofollow Highlighter
1.5 20210125    Icon alerting
1.4 20201228	Ga via gtag con nonce
1.3 20201218	Ga via gtag and anonymized IP
1.2 20201216    AMP, title, meta desc, ga
1.1 20201214    Hreflang: Split hreflang from href and fix style
1.0 20201210    First Attemp
---
Idee
- Status Code della pagina (non tracing)
- N° link esterni, n° link interni
