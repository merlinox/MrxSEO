var currentVersion = "1.1";
var currentTab = "";
var differentUrlSign = "&#9888;&#65039;";

function canonicals(cs) {
  console.log("canonicals");
  console.log(cs);
  var html = "";
  var differentUrl = "";
  if (cs.length > 0) {
    html += "<ol>";
    for (var i = 0; i < cs.length; i++) {
      if (currentTab.url != cs[i]){ differentUrl = " " + differentUrlSign;};
      html += "<li><a href='" + cs[i] + "' target='_blank'>" + cs[i] + "</a>" + differentUrl  + "</li>";
    }
    html += "</ol>";
  } else {
    html += "None";
  }
  document.getElementById("dCanonical").innerHTML = html;
  document.getElementById("current").innerHTML = "<a href='" + currentTab.url + "' target='_blank'>" + currentTab.url + "</a>";
  document.getElementById("currentVersion").innerHTML = "Version " + currentVersion;
}

function hreflangs(cs) {
  console.log("hreflangs");
  console.log(cs);
  var html = "";
  var elem;
  if (cs.length > 0) {
    html += "<table id='hreflang'>";
    
    for (var i = 0; i < cs.length; i++) {
      elem = cs[i];
      html += "<tr><td>" + elem.hreflang + "</td><td><a href='" + elem.href + "' target='_blank'>" + elem.href + "</a></td></tr>";
    }
    html += "</table>";
  } else {
    html += "None";
  }
  document.getElementById("dHreflang").innerHTML = html;
}

function robots(cs) {
  console.log("robots");
  console.log(cs);
  var html = "";
  if (cs.length > 0) {
    html += "<ol>";
    for (var i = 0; i < cs.length; i++) {
      html += "<li>" + cs[i] + "</li>";
    }
    html += "</ol>";
  } else {
    html += "None";
  }
  document.getElementById("dMetaRobots").innerHTML = html;
}


function main() {
  //https://stackoverflow.com/questions/1964225/accessing-current-tab-dom-object-from-popup-html
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { action: "getCanonicals" }, function (response) {
      console.log(response.farewell);
      canonicals(response.farewell);
    });
    chrome.tabs.sendMessage(tabs[0].id, { action: "getHreflangs" }, function (response) {
      console.log(response.farewell);
      hreflangs(response.farewell);
    });
    chrome.tabs.sendMessage(tabs[0].id, { action: "getRobots" }, function (response) {
      console.log(response.farewell);
      robots(response.farewell);
    });

    currentTab = tabs[0];
  });

}

main();