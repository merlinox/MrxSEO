
var prefix = "SEO Mrx";
var debug = isDevMode();
console.log(prefix + ": Loaded")

function isDevMode() {
  return !('update_url' in chrome.runtime.getManifest());
}

function logme(t) {
  if (debug) console.log(prefix + ": " + t);
}
function logmeVoid(t) {
  if (debug) console.log(t);
}


function getCanonicals() {
  var cs = document.querySelectorAll("link[rel='canonical']");
  return cs;
}
function getCanonicalHrefs() {
  var cs = [];
  var css = getCanonicals();
  for (var i = 0; i < css.length; i++) {
    cs.push(css[i].href);
  }
  return cs;
}

function getHreflangs() {
  var cs = document.querySelectorAll("link[rel='alternate'][hreflang]");
  return cs;
}
function getHreflangDetails() {
  var cs = [];
  var css = getHreflangs();
  var item;
  for (var i = 0; i < css.length; i++) {
    item = {};
    item.hreflang = css[i].hreflang;
    item.href = css[i].href;

    //cs.push(JSON.stringify(item));
    cs.push(item);
  }
  console.log("content:getHreflangDetails");
  console.log(cs);
  return cs;
}

function getRobots(){
  var cs = document.querySelectorAll("meta[name='robots'],meta[name='googlebots'],meta[name='bingbots']");
  return cs;
}

function getRobotsDetails() {
  var cs = [];
  var css = getRobots();
  var item;
  for (var i = 0; i < css.length; i++) {
    cs.push("[" + css[i].name + "] " + css[i].content);
  }
  return cs;
}




chrome.runtime.onMessage.addListener(
  function (request, sender, sendResponse) {
    var rs;
    switch (request.action) {
      case "getDocument":
        sendResponse({ farewell: document });
        break;
      case "getWindow":
        sendResponse({ farewell: window });
        break;
      case "getData":
        rs = window.getData();
        sendResponse({ farewell: rs });
        break;
      case "getCanonicals":
        rs = window.getCanonicalHrefs();
        sendResponse({ farewell: rs });
        break;
        case "getHreflangs":
          rs = window.getHreflangDetails();
          sendResponse({ farewell: rs });
          break;
          case "getRobots":
          rs = window.getRobotsDetails();
          sendResponse({ farewell: rs });
          break;
      default:
        sendResponse({ farewell: 'none' });
        break;
    }
  }
);