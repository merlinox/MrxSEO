1.0 20201210    First Attemp
1.1 20201214    Hreflang: Split hreflang from href and fix style
1.5 20210124    When canonical is different by location, icon become in alert mode
